minetest.register_craft({
	output = 'advtrains:subway_wagon_810a',
	recipe = {
		{'default:steelblock', 'default:steelblock', 'default:steelblock'},
		{'default:steelblock', 'default:steelblock', 'dye:blue'},
		{'default:steelblock', 'default:steelblock', 'default:steelblock'},
	},
})

minetest.register_craft({
	output = 'advtrains:subway_wagon_810b',
	recipe = {
		{'default:steelblock', 'default:steelblock', 'default:steelblock'},
		{'default:steelblock', 'default:steelblock', 'dye:red'},
		{'default:steelblock', 'default:steelblock', 'default:steelblock'},
	},
})
