Czechtrains is a mod by MatyasP that adds real paints of trains, using subway trains from advtrains mod. Created from discotrains mod by sivarajansam.
